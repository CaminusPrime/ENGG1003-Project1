#include <stdio.h>
#include <string.h>

char capital(char c);
char rotation(char c, int x);

int main() 
{
    
char hdCodemsg[] = "SJSFMPCRM WG O USBWIG. PIH WT MCI XIRUS O TWGV PM WHG OPWZWHM HC QZWAP O HFSS, WH KWZZ ZWJS WHG KVCZS ZWTS PSZWSJWBU HVOH WH WG GHIDWR. - OZPSFH SWBGHSWB";
char res[1024];
int x = 1; // Counter
char c;

// Print initial value
printf("Rotation: 0\nMessage: %s\n\n", hdCodemsg);
while(x < 26) 
    
        {
            
        for (int i = 0; i < strlen(hdCodemsg); i++)
             {
                c = hdCodemsg[i];
                res[i] = capital(c);    
                //printf("ASCII value of %c = %d\n", res[i], res[i]);
            }
            
        for(int i= 0; i < strlen(hdCodemsg); i++)
            {
            res[i] = rotation(res[i],x);
            }
            printf("Rotation: %d\nMessage: %s\n\n",x, res);
            x = x + 1;
            }    
        
    
    
      printf("enter rotation amount : ");
      scanf("%d", &x);
      {
      for (int i = 0; i < strlen(hdCodemsg); i++)
             {
                c = hdCodemsg[i];
                res[i] = capital(c);    
                //printf("ASCII value of %c = %d\n", res[i], res[i]);
            }
            
        for(int i= 0; i < strlen(hdCodemsg); i++)
            {
            res[i] = rotation(res[i],x);
            }
            printf("Rotation: %d\nMessage: %s\n\n",x, res);
           
            }  
            
    
    

    return 0;
}


char capital(char c)
{
	if ((c <= 64) || (c >= 91 && c <= 96) || (c >= 123 && c <= 126)) // returning non letter outputs
	{
		//printf("%c", c);
		return c;
	}
	else if (c >= 97 && c <= 122)
	{
		//printf("lower case letter detected\n"); // used for testing
		c -= 32; // this captializes the letter using ASCII
		return c;
	}
}

char rotation(char c, int x)
{
	char r;
	r = c + x;
	if ((c >= 32 && c <= 64) || (c >= 91 && c <= 96) || (c >= 123 && c <= 126)) // returning non letter outputs
	{
		//printf("%c", c);
		return c;
	}
	if (r >= 91)
	{
		int e;
		e = (x + c) - 91;
		r = 65 + e;
	}
	if (r <= 64)
	{
		int e;
		e = (x + c) - 65;
		r = 91 + e;
	}

	//printf("value of rotation = %c // %d", r, r);

	return r;
}