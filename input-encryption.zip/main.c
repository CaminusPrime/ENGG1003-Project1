#include <stdio.h>
#include <string.h>
//#include <conio.h>


char capital(char c);
char rotation(char str, int x);

int main()
{
	char c;
	char str[1024];
 	char res[1024]; // result
	int x;    
    printf("Enter : "); // Reads character input from the user
    scanf("%[^\n]s", str);
  
  for (int i = 0; i < strlen(str); i++)
  {
    c = str[i];
    res[i] = capital(c);    
    //printf("ASCII value of %c = %d\n", res[i], res[i]);
    }
    
   printf("capitalised: %s\n", res); // Outputs capitalised result

   
    // %d displays the integer value of a character
    // %c displays the actual character
   // printf("ASCII value of %c = %d\n", c, c);


    //printf("ASCII value of %c = %d\n", c, c);

    
    printf("enter rotation amount : ");

    scanf("%d", &x);
     for(int i= 0; i < strlen(str); i++)
      {
        res[i] = rotation(res[i],x);
      }

     printf("Enctypted to: %s\n", res);
    return 0;
}











// function for reading and converting to captials 
char capital(char c)
{
      if(c >= 97 && c <= 122)
    {
        //printf("lower case letter detected\n");
        c -= 32; // this captializes the letter using ASCII
        return c;
    }
    else if ((c >= 32 && c < 64)|| (c >= 91 && c <= 96) || (c >= 123 && c <= 126)) // returning non letter outputs
    {
       // printf("%c", c);
        return c;
    }
}


char rotation(char c, int x)
{
    char r;
    r = c + x;
    if((c >= 32 && c <= 64)|| (c >= 91 && c <= 96) || (c >= 123 && c <= 126)) // returning non letter outputs
    {
        //printf("%c", c);
        return c;
    }
    if(r >= 91)
    {
      int e;
      e = (x + c) - 91;
      r = 65 + e; 
    }
    if(r <= 64)
    {
      int e;
      e = (x + c) - 65;
      r = 91 + e; 
    }
    
    //printf("value of rotation = %c // %d", r, r);
    
    return r;
}
